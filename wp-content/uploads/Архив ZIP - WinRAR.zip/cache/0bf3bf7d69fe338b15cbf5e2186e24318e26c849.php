<div class="modal" id="search">
  <button type="button" class="close">×</button>
  <form action="#" method="post">
    <input type="search" value="" placeholder="Что ищем?" />
    <button type="submit" class="btn btn-primary">Искать</button>
  </form>
</div>
