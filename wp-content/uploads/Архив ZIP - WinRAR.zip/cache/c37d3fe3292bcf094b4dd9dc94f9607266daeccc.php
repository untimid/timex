<nav class="side-navigation navbar" id="navbar">
  <ul class="side-navigation-list">
    <li class="side-navigation-item">
      <a class="nav-link" href="#section1">Кто мы <span></span></a>
    </li>
    <li class="side-navigation-item">
      <a class="nav-link" href="#section2">Что мы делаем <span></span></a>
    </li>
    <li class="side-navigation-item">
      <a class="nav-link" href="#section3">Почему мы <span></span></a>
    </li>
    <li class="side-navigation-item">
      <a class="nav-link" href="#section4">Новости <span></span></a>
    </li>
    <li class="side-navigation-item">
      <a class="nav-link" href="#section5">Партнеры <span></span></a>
    </li>
  </ul>
</nav>
